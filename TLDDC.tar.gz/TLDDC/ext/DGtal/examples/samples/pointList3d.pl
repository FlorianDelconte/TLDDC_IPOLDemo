# Define to test PointListReader ...
1 2 3
1 44 4
1 23 4
#0  0 0 
1 2 10
